// =============================================
// APP STATE
// =============================================
let state = {
  activeChat: null,
  theme: localStorage.getItem('chat-theme') || 'light',
  infoPanelOpen: false,
  leads: [],
  currentMessages: [],
  periodFilter: 'todos',
  ordersPage: 1,
  ordersPerPage: 10,
  currentFilteredVendas: [],
  productsPage: 1,
  productsPerPage: 5,
  currentTopProducts: [],
  choicesPage: 1,
  choicesPerPage: 8,
  currentTopChoices: [],
  importHeaders: [],
  importRows: [],
  importMapping: {}
};

// =============================================
// DOM REFERENCES
// =============================================
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const conversationListPane = $('#conversation-list-pane');
const chatList = $('#chat-list');
const searchInput = $('#search-input');
const contentArea = $('#content-area');
const emptyState = $('#empty-state');
const chatHeader = $('#chat-header');
const contactAvatar = $('#contact-avatar');
const contactName = $('#contact-name');
const contactStatus = $('#contact-status');
const messagesContainer = $('#messages-container');
const messagesList = $('#messages-list');
const infoPanel = $('#info-panel');
const infoPanelBody = $('#info-panel-body');

// =============================================
// THEME
// =============================================
function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  state.theme = theme;
  localStorage.setItem('chat-theme', theme);
  
  const btn = $('#btn-theme-toggle');
  if (btn) {
    btn.innerHTML = theme === 'dark'
      ? '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>'
      : '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
  }
}

// =============================================
// RENDER CHAT LIST
// =============================================
function renderChatList(filter = '') {
  const filtered = state.leads.filter(lead =>
    (lead.lead_nome || '').toLowerCase().includes(filter.toLowerCase()) ||
    (lead.lead_telefone || '').toLowerCase().includes(filter.toLowerCase())
  );

  chatList.innerHTML = filtered.map(lead => {
    const preview = lead.lead_mensagem || '';
    const time = lead.criado_em ? new Date(lead.criado_em).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
    const unread = 0; // Not tracked in DB yet
    const isActive = state.activeChat === lead.lead_id;

    const name = lead.lead_nome || 'Lead Sem Nome';
    const initials = lead.is_no_lead ? 'NL' : name.substring(0, 2).toUpperCase();
    const color = lead.is_no_lead ? '#e63946' : getAvatarColor(lead.lead_id);

    return `
      <div class="chat-item ${isActive ? 'active' : ''} ${unread > 0 ? 'unread' : ''}"
           data-id="${lead.lead_id}" id="chat-item-${lead.lead_id}">
        <div class="chat-item-avatar" style="background: ${color}">
          ${initials}
        </div>
        <div class="chat-item-content">
          <div class="chat-item-row">
            <span class="chat-item-name">${name}</span>
            <span class="chat-item-time">${time}</span>
          </div>
          <div class="chat-item-row-bottom">
            <span class="chat-item-preview">${truncate(preview, 45)}</span>
            ${unread > 0 ? `<span class="unread-badge">${unread}</span>` : ''}
          </div>
        </div>
      </div>
    `;
  }).join('');

  // Attach click events
  chatList.querySelectorAll('.chat-item').forEach(el => {
    el.addEventListener('click', () => openChat(el.dataset.id));
  });
}

function getAvatarColor(idStr) {
  if (!idStr) return '#4a5a64';
  let hash = 0;
  for (let i = 0; i < idStr.length; i++) {
    hash = idStr.charCodeAt(i) + ((hash << 5) - hash);
  }
  const c = (hash & 0x00FFFFFF).toString(16).toUpperCase();
  return '#' + '00000'.substring(0, 6 - c.length) + c;
}

function truncate(str, len) {
  if (!str) return '';
  // Strip markdown-like formatting for preview
  const clean = str.replace(/\*\*/g, '').replace(/\n/g, ' ');
  return clean.length > len ? clean.slice(0, len) + '…' : clean;
}

// =============================================
// OPEN CHAT & FETCH MESSAGES
// =============================================
async function fetchMessages(leadId) {
  messagesList.innerHTML = '<div style="text-align: center; padding: 20px; color: #8696a0;">Carregando mensagens...</div>';

  let query = db.from('samukas_mensagens').select('*');
  if (leadId === 'no_lead') {
    query = query.is('lead_id', null);
  } else {
    query = query.eq('lead_id', leadId);
  }

  const { data, error } = await query.order('criado_em', { ascending: true });

  if (error) {
    console.error('Error fetching messages:', error);
    messagesList.innerHTML = '<div style="text-align: center; padding: 20px; color: #e63946;">Erro ao carregar mensagens</div>';
    return;
  }

  state.currentMessages = data || [];
  renderMessages(state.currentMessages, state.leads.find(l => l.lead_id === leadId));
  update24hWindowUI(state.currentMessages);

  // Scroll to bottom
  setTimeout(() => {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }, 50);
}

// =============================================
// MESSAGE TEMPLATE CATALOG
// =============================================
// Metadata for known WhatsApp templates fired by the "Disparo de Mensagens"
// automation. mensagem_template (saved by n8n) is looked up here to know
// whether to render an image header and/or an action button alongside the
// text. Adding a future template only requires a new entry here — no
// changes to the rendering logic below.
const MESSAGE_TEMPLATES = {
  cupom_botao: {
    label: 'Cupom + Botão (Imagem)',
    body: 'Ótima notícia {{nome}}! Preparamos um presente especial para o seu jantar hoje. 🍔\n\nSentimos sua falta no Samukas! Liberamos o cupom SMK15 para você aproveitar 15% de desconto no seu próximo pedido.\n\nVálido por tempo limitado. Toque no botão abaixo para fazer seu pedido!',
    image: 'https://mnoknmzkmqbkbyobjzuh.supabase.co/storage/v1/object/public/visi-marketing/samukas_burguer.jpeg',
    button: { text: 'Aproveitar Agora', url: 'https://samukasburger.saipos.com/home' }
  },
  cupom_15: {
    label: 'Cupom 15 (Texto Simples)',
    body: 'Ótima noticia {{nome}}!! 15% OFF no seu pedido hoje! 🍔 \n\nVocê já provou o Samukas e a gente quer te ver de volta.\n\nUse o cupom SMK15 e garante seu desconto agora.\n\n👉 https://samukasburger.saipos.com/home\n\nCorre, é por tempo limitado! ⏳'
  }
};

// Builds the inner HTML of a message bubble (image + text + button) from a
// template's catalog entry and the literal text to show. Shared by the real
// chat renderer and the Configurações preview, so both stay in sync.
function buildMessageBubbleInner(template, text) {
  const formattedText = formatMessageText(text || '');
  const imageHtml = template.image
    ? `<div class="message-media"><img src="${template.image}" alt="" loading="lazy" /></div>`
    : '';
  const buttonHtml = template.button
    ? `<a class="message-template-button" href="${template.button.url}" target="_blank" rel="noopener noreferrer">${template.button.text}</a>`
    : '';
  return `${imageHtml}<div class="message-text">${formattedText}</div>${buttonHtml}`;
}

// =============================================
// TEMPLATE PREVIEWS (Configurações page)
// =============================================
function renderTemplatePreviews() {
  const container = $('#template-previews');
  if (!container) return;

  container.innerHTML = Object.entries(MESSAGE_TEMPLATES).map(([key, tpl]) => {
    const sampleText = (tpl.body || '').replace(/\{\{nome\}\}/g, 'Cliente');
    return `
      <div class="template-preview">
        <div class="template-preview-label">${tpl.label || key}</div>
        <div class="template-preview-phone">
          <div class="message outgoing">
            <div class="message-bubble">
              ${buildMessageBubbleInner(tpl, sampleText)}
              <div class="message-footer"><span class="message-time">agora</span></div>
            </div>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// =============================================
// RENDER MESSAGES
// =============================================
function renderMessages(messages, lead) {
  if (messages.length === 0) {
    messagesList.innerHTML = '<div style="text-align: center; padding: 20px; color: #8696a0;">Nenhuma mensagem encontrada.</div>';
    return;
  }

  messagesList.innerHTML = messages.map(msg => {
    // Assume origin 'cliente' is incoming, everything else is outgoing
    const isOutgoing = (msg.mensagem_origem || '').toLowerCase() !== 'cliente';
    const statusIcon = getStatusIcon(msg.mensagem_status || 'read');
    const template = MESSAGE_TEMPLATES[msg.mensagem_template] || {};

    // Format time
    const time = msg.criado_em ? new Date(msg.criado_em).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';

    return `
      <div class="message ${isOutgoing ? 'outgoing' : 'incoming'}" id="msg-${msg.mensagem_id}">
        <div class="message-bubble">
          ${buildMessageBubbleInner(template, msg.mensagem_conteudo)}
          <div class="message-footer">
            <span class="message-time">${time}</span>
            ${isOutgoing ? `<span class="message-status ${msg.mensagem_status || 'read'}">${statusIcon}</span>` : ''}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function formatMessageText(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer" style="color: var(--accent); text-decoration: underline;">$1</a>')
    .replace(/\n/g, '<br>');
}

function getStatusIcon(status) {
  if (status === 'sent') {
    return '<svg width="16" height="11" viewBox="0 0 16 11"><path d="M11 1L4.5 8.5L1.5 5.5" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>';
  }
  if (status === 'delivered') {
    return '<svg width="20" height="11" viewBox="0 0 20 11"><path d="M14 1L7.5 8.5L5 6" stroke="currentColor" stroke-width="1.5" fill="none"/><path d="M10 1L3.5 8.5L1.5 6.5" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>';
  }
  if (status === 'read') {
    return '<svg width="20" height="11" viewBox="0 0 20 11"><path d="M14 1L7.5 8.5L5 6" stroke="#e63946" stroke-width="1.5" fill="none"/><path d="M10 1L3.5 8.5L1.5 6.5" stroke="#e63946" stroke-width="1.5" fill="none"/></svg>';
  }
  return '';
}

function getSenderColor(name) {
  const colors = ['#e88ca5', '#5b9bd5', '#6dbf67', '#e8a838', '#8e7cc3', '#c25b5b', '#42a5a5', '#d4609a'];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
}

// =============================================
// WHATSAPP 24-HOUR WINDOW CALCULATOR & UI
// =============================================
function update24hWindowUI(messages) {
  const chatFooter = $('#chat-footer');
  const banner = $('#whatsapp-window-banner');
  const chatInput = $('#chat-input');
  const sendBtn = $('#btn-send-message');

  if (!chatFooter || !banner || !chatInput || !sendBtn) return;

  chatFooter.classList.remove('hidden');

  // Filter incoming client messages
  const clientMsgs = (messages || []).filter(m => (m.mensagem_origem || '').toLowerCase() === 'cliente');

  if (clientMsgs.length === 0) {
    state.window24h = { active: false, reason: 'no_msg' };
    banner.className = 'whatsapp-window-banner no-msg';
    banner.innerHTML = `
      <span class="badge-pulse"></span>
      <span><strong>Janela 24h WhatsApp:</strong> Nenhuma mensagem enviada pelo cliente ainda. Apenas modelos pré-aprovados permitidos.</span>
    `;
    chatInput.disabled = true;
    chatInput.placeholder = 'Aguardando o cliente responder para abrir a janela de 24h...';
    sendBtn.disabled = true;
    return;
  }

  // Get most recent client message
  const lastMsg = clientMsgs[clientMsgs.length - 1];
  const lastDate = new Date(lastMsg.criado_em);
  const now = new Date();
  const diffMs = now.getTime() - lastDate.getTime();
  const diffHours = diffMs / (1000 * 60 * 60);

  if (diffHours < 24) {
    const totalMinsLeft = Math.floor((24 * 60) - (diffMs / (1000 * 60)));
    const hLeft = Math.floor(totalMinsLeft / 60);
    const mLeft = totalMinsLeft % 60;

    state.window24h = { active: true, hLeft, mLeft, lastDate };

    banner.className = 'whatsapp-window-banner active';
    banner.innerHTML = `
      <span class="badge-pulse"></span>
      <span><strong>🟢 Janela 24h Aberta:</strong> O cliente mandou mensagem recentemente. Restam <strong>${hLeft}h ${mLeft}min</strong> para responder livremente.</span>
    `;
    chatInput.disabled = false;
    chatInput.placeholder = 'Digite sua mensagem para o cliente...';
    sendBtn.disabled = false;
  } else {
    state.window24h = { active: false, reason: 'expired', lastDate };

    const hoursAgo = Math.floor(diffHours);
    banner.className = 'whatsapp-window-banner expired';
    banner.innerHTML = `
      <span class="badge-pulse"></span>
      <span><strong>🔴 Janela 24h Expirada:</strong> Última mensagem do cliente foi há ${hoursAgo}h. Apenas mensagens de modelo/template podem ser enviadas.</span>
    `;
    chatInput.disabled = true;
    chatInput.placeholder = 'Janela de 24h fechada — Aguarde o cliente enviar mensagem para reabrir...';
    sendBtn.disabled = true;
  }
}

async function sendMessageToLead(text) {
  if (!state.activeChat || !state.window24h || !state.window24h.active) {
    alert('Não é possível enviar mensagem: A janela de 24h do WhatsApp está fechada.');
    return;
  }

  const lead = state.leads.find(l => l.lead_id === state.activeChat);
  if (!lead || !lead.lead_telefone) {
    alert('Telefone do lead não encontrado.');
    return;
  }

  const chatInput = $('#chat-input');
  const sendBtn = $('#btn-send-message');
  if (chatInput) chatInput.disabled = true;
  if (sendBtn) sendBtn.disabled = true;

  try {
    // 1. Send via Meta WhatsApp Official API
    const metaPayload = {
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: lead.lead_telefone,
      type: "text",
      text: { preview_url: false, body: text }
    };

    const tokenMeta = (window.ENV && window.ENV.TOKEN_META) ? window.ENV.TOKEN_META : "EAGPsZBbZAJkuYBSQMrTOJZBxih2C79AxCC2lCE0HEaN8k6QyetFhC7ycIGypQSbvdEXZAOUjcVduxkf3KKiK6m7w7fOtRm1va5KvkRsK6ZBNlv5fOMLyLjqTiPxxBnSZBBExrvKwgql6lCgQa3pNvFsNUlYeHKZAORMcsY17BZBRbUMRhsZBS93CDtkNiU0JO4wZDZD";
    const apiPhoneId = (window.ENV && window.ENV.API_WHATSAPP) ? window.ENV.API_WHATSAPP : "1312724251922734";

    const metaRes = await fetch(`https://graph.facebook.com/v20.0/${apiPhoneId}/messages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${tokenMeta}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(metaPayload)
    });

    const metaData = await metaRes.json();
    console.log('Meta API Send Result:', metaData);

    let wamid = null;
    let msgStatus = 'sent';
    if (metaData && metaData.messages && metaData.messages[0]) {
      wamid = metaData.messages[0].id;
    } else if (metaData && metaData.error) {
      msgStatus = 'failed: ' + (metaData.error.message || 'Erro Meta');
    }

    // 2. Save to Supabase samukas_mensagens
    const { data: insertedMsg, error: supaErr } = await db.from('samukas_mensagens').insert([{
      lead_id: lead.lead_id === 'no_lead' ? null : lead.lead_id,
      mensagem_conteudo: text,
      mensagem_origem: 'Atendente',
      mensagem_status: msgStatus,
      mensagem_provedor_id: wamid
    }]).select('*');

    if (supaErr) {
      console.error('Erro ao salvar no Supabase:', supaErr);
    }

    if (chatInput) chatInput.value = '';

    // Re-fetch messages
    await fetchMessages(state.activeChat);

  } catch (err) {
    console.error('Erro ao enviar mensagem:', err);
    alert('Erro ao enviar mensagem via WhatsApp Meta API: ' + err.message);
  } finally {
    if (chatInput) chatInput.disabled = false;
    if (sendBtn) sendBtn.disabled = false;
    if (chatInput) chatInput.focus();
  }
}



// =============================================
// INFO PANEL
// =============================================
function openInfoPanel() {
  const contact = state.leads.find(c => c.lead_id === state.activeChat);
  if (!contact) return;

  state.infoPanelOpen = true;
  infoPanel.classList.add('open');

  if (contact.is_no_lead) {
    infoPanelBody.innerHTML = `
      <div style="text-align: center; padding: 24px 16px; border-bottom: 1px solid var(--border);">
        <div class="chat-item-avatar" style="background: #e63946; width: 72px; height: 72px; font-size: 28px; margin: 0 auto 16px auto; display: flex; align-items: center; justify-content: center; border-radius: 50%; color: #fff; font-weight: bold; box-shadow: 0 4px 16px rgba(230,57,70,0.3);">NL</div>
        <h3 style="margin-bottom: 4px; font-size: 18px; color: var(--text-primary); font-weight: 600;">Novo Lead</h3>
        <p style="color: var(--text-secondary); font-size: 13px;">Mensagens sem vínculo com nenhum lead</p>
      </div>
      <div style="padding: 16px;">
        <div style="background: var(--bg-tertiary, rgba(255,255,255,0.03)); border: 1px solid var(--border); border-radius: 12px; padding: 14px 16px;">
          <div style="font-size: 11px; color: var(--text-tertiary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; font-weight: 600;">Status</div>
          <div style="font-size: 14px; color: var(--text-primary); font-weight: 500;">Não identificado no sistema</div>
        </div>
      </div>
    `;
    return;
  }

  const name = contact.lead_nome || 'Lead Sem Nome';
  const initials = name.substring(0, 2).toUpperCase();
  const color = getAvatarColor(contact.lead_id);
  const phone = contact.lead_telefone || 'Não informado';
  const pedidos = contact.lead_quantidade_pedidos || 0;
  const ticket = contact.lead_ticket_medio != null 
    ? `R$ ${Number(contact.lead_ticket_medio).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` 
    : 'R$ 0,00';
  const ultimaCompra = contact.lead_ultima_compra 
    ? new Date(contact.lead_ultima_compra).toLocaleDateString('pt-BR') 
    : 'Sem registros';
  const dataDisparo = contact.data_disparo_mensagem 
    ? new Date(contact.data_disparo_mensagem).toLocaleDateString('pt-BR') + ' ' + new Date(contact.data_disparo_mensagem).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : 'Não informada';

  infoPanelBody.innerHTML = `
    <div style="text-align: center; padding: 24px 16px; border-bottom: 1px solid var(--border);">
      <div class="chat-item-avatar" style="background: ${color}; width: 72px; height: 72px; font-size: 28px; margin: 0 auto 16px auto; display: flex; align-items: center; justify-content: center; border-radius: 50%; color: #fff; font-weight: bold; box-shadow: 0 4px 16px rgba(0,0,0,0.2);">${initials}</div>
      <h3 style="margin-bottom: 4px; font-size: 18px; color: var(--text-primary); font-weight: 600;">${name}</h3>
      <p style="color: var(--text-secondary); font-size: 13px;">${phone}</p>
    </div>

    <div style="padding: 16px; display: flex; flex-direction: column; gap: 12px;">
      <div style="background: var(--bg-tertiary, rgba(255,255,255,0.03)); border: 1px solid var(--border); border-radius: 12px; padding: 14px 16px;">
        <div style="font-size: 11px; color: var(--text-tertiary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; font-weight: 600;">Telefone</div>
        <div style="font-size: 14px; color: var(--text-primary); font-weight: 500;">${phone}</div>
      </div>

      <div style="background: var(--bg-tertiary, rgba(255,255,255,0.03)); border: 1px solid var(--border); border-radius: 12px; padding: 14px 16px;">
        <div style="font-size: 11px; color: var(--text-tertiary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; font-weight: 600;">Quantidade de Pedidos</div>
        <div style="font-size: 14px; color: var(--text-primary); font-weight: 500;">${pedidos}</div>
      </div>

      <div style="background: var(--bg-tertiary, rgba(255,255,255,0.03)); border: 1px solid var(--border); border-radius: 12px; padding: 14px 16px;">
        <div style="font-size: 11px; color: var(--text-tertiary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; font-weight: 600;">Ticket Médio</div>
        <div style="font-size: 14px; color: var(--accent); font-weight: 600;">${ticket}</div>
      </div>

      <div style="background: var(--bg-tertiary, rgba(255,255,255,0.03)); border: 1px solid var(--border); border-radius: 12px; padding: 14px 16px;">
        <div style="font-size: 11px; color: var(--text-tertiary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; font-weight: 600;">Última Compra</div>
        <div style="font-size: 14px; color: var(--text-primary); font-weight: 500;">${ultimaCompra}</div>
      </div>

      <div style="background: var(--bg-tertiary, rgba(255,255,255,0.03)); border: 1px solid var(--border); border-radius: 12px; padding: 14px 16px;">
        <div style="font-size: 11px; color: var(--text-tertiary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; font-weight: 600;">Data do Disparo</div>
        <div style="font-size: 14px; color: var(--text-primary); font-weight: 500;">${dataDisparo}</div>
      </div>

      <!-- Pedidos & Itens do Cliente -->
      <div id="contact-orders-box" style="background: var(--bg-tertiary, rgba(255,255,255,0.03)); border: 1px solid var(--border); border-radius: 12px; padding: 14px 16px;">
        <div style="font-size: 11px; color: var(--text-tertiary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; font-weight: 600;">Itens Comprados pelo Cliente</div>
        <div id="contact-orders-content" style="font-size: 13px; color: var(--text-secondary);">Carregando itens...</div>
      </div>
    </div>
  `;

  // Fetch orders from samukas_vendas for this lead
  db.from('samukas_vendas')
    .select('*')
    .or(`lead_id.eq.${contact.lead_id},cliente_telefone.eq.${contact.lead_telefone}`)
    .order('criado_em', { ascending: false })
    .then(({ data: vendas, error }) => {
      const ordersBox = $('#contact-orders-content');
      if (!ordersBox) return;

      if (error || !vendas || vendas.length === 0) {
        ordersBox.innerHTML = '<span style="color: var(--text-tertiary); font-style: italic;">Nenhum pedido com cupom registrado ainda.</span>';
        return;
      }

      ordersBox.innerHTML = vendas.map(v => {
        const val = Number(v.total_vendido || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        const dataStr = v.criado_em ? new Date(v.criado_em).toLocaleDateString('pt-BR') : '';
        const itens = Array.isArray(v.itens_pedido) ? v.itens_pedido : [];

        return `
          <div style="border-top: 1px solid rgba(255,255,255,0.06); padding-top: 8px; margin-top: 8px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
              <span style="font-weight: 600; color: #ffcc00; font-size: 0.85rem;">${val}</span>
              <span style="font-size: 0.72rem; color: var(--text-tertiary);">${dataStr}</span>
            </div>
            ${itens.length > 0 ? itens.map(i => `
              <div style="font-size: 0.8rem; color: var(--text-primary); margin-bottom: 2px;">
                <span style="color: #ff6b6b; font-weight: 700;">${i.quantidade}x</span> ${i.nome}
              </div>
              ${(i.opcoes || []).length > 0 ? `
                <div style="display: flex; flex-wrap: wrap; gap: 3px; margin-bottom: 4px;">
                  ${i.opcoes.map(o => `<span class="order-choice-chip" style="font-size: 0.68rem; padding: 1px 5px;">${o.nome}</span>`).join('')}
                </div>
              ` : ''}
              ${i.observacoes ? `<div style="font-size: 0.7rem; color: #a0a0a0; font-style: italic; margin-bottom: 4px;">💬 ${i.observacoes}</div>` : ''}
            `).join('') : '<span style="font-size: 0.75rem; color: var(--text-tertiary);">Itens não especificados</span>'}
          </div>
        `;
      }).join('');
    });
}

function closeInfoPanel() {
  state.infoPanelOpen = false;
  infoPanel.classList.remove('open');
}

// =============================================
// EMOJI PICKER
// =============================================


// =============================================
// LOGIN & SUPABASE INIT
// =============================================
let db;
try {
  db = window.supabase.createClient(ENV.SUPABASE_URL, ENV.SUPABASE_ANON_KEY);
} catch (e) {
  alert("Erro fatal: O Supabase não carregou. Se você usa AdBlock ou Brave, desative os escudos para esta página. Erro: " + e.message);
}

function initLogin() {
  const loginScreen = $('#login-screen');
  const loginForm = $('#login-form');
  const loginEmail = $('#login-email');
  const loginPassword = $('#login-password');
  const loginBtn = $('#login-btn');
  const togglePassword = $('#toggle-password');
  const app = $('#app');

  // Supabase auth state listener
  db.auth.onAuthStateChange((event, session) => {
    if (event === 'SIGNED_IN' && session) {
      const card = loginScreen.querySelector('.login-card');
      card.classList.add('success');
      loginScreen.classList.add('fade-out');
      
      setTimeout(() => {
        loginScreen.classList.add('hidden');
        app.classList.remove('hidden');
        initChat();
      }, 600);
    } else if (event === 'SIGNED_OUT') {
      app.classList.add('hidden');
      loginScreen.classList.remove('hidden');
      loginScreen.classList.remove('fade-out');
      const card = loginScreen.querySelector('.login-card');
      card.classList.remove('success');
    }
  });

  // Check current session
  db.auth.getSession().then(({ data: { session } }) => {
    if (session) {
      loginScreen.classList.add('hidden');
      app.classList.remove('hidden');
      initChat();
    }
  });

  // Toggle password visibility
  togglePassword.addEventListener('click', () => {
    const isPassword = loginPassword.type === 'password';
    loginPassword.type = isPassword ? 'text' : 'password';
    togglePassword.innerHTML = isPassword
      ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>'
      : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
  });

  // Clear errors on input
  loginEmail.addEventListener('input', () => {
    loginEmail.classList.remove('error');
    removeError(loginEmail);
  });
  loginPassword.addEventListener('input', () => {
    loginPassword.classList.remove('error');
    removeError(loginPassword);
  });

  // Form submit
  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    handleLogin(loginEmail, loginPassword, loginBtn, loginScreen, app);
  });

  // Forgot password — sends a real Supabase Auth reset email
  $('#forgot-password').addEventListener('click', async (e) => {
    e.preventDefault();
    removeError(loginEmail);

    const email = loginEmail.value.trim();
    if (!email || !loginEmail.validity.valid) {
      loginEmail.classList.add('error');
      showError(loginEmail, 'Digite seu e-mail acima para receber o link de redefinição');
      loginEmail.focus();
      return;
    }

    const link = $('#forgot-password');
    const originalText = link.textContent;
    link.textContent = 'Enviando...';

    const { error } = await db.auth.resetPasswordForEmail(email, {
      redirectTo: window.location.origin
    });

    link.textContent = originalText;

    if (error) {
      loginEmail.classList.add('error');
      showError(loginEmail, 'Não foi possível enviar o e-mail: ' + error.message);
    } else {
      removeError(loginEmail);
      showError(loginEmail, 'E-mail de redefinição enviado! Confira sua caixa de entrada.');
      const errEl = loginEmail.closest('.form-group').querySelector('.form-error');
      if (errEl) errEl.classList.add('form-success');
    }
  });
}

async function handleLogin(emailInput, passwordInput, btn, loginScreen, app) {
  try {
    // Validate
    let valid = true;
    if (!emailInput.value.trim() || !emailInput.validity.valid) {
      emailInput.classList.add('error');
      showError(emailInput, 'Insira um e-mail válido');
      valid = false;
    }
    if (!passwordInput.value || passwordInput.value.length < 3) {
      passwordInput.classList.add('error');
      showError(passwordInput, 'A senha deve ter pelo menos 3 caracteres');
      valid = false;
    }
    if (!valid) return;

    // Show loading state
    btn.classList.add('loading');
    btn.querySelector('.login-btn-text').classList.add('hidden');
    btn.querySelector('.login-btn-loader').classList.remove('hidden');

    const email = emailInput.value.trim();
    const password = passwordInput.value;

    const { data, error } = await db.auth.signInWithPassword({
      email,
      password
    });

    btn.classList.remove('loading');
    btn.querySelector('.login-btn-text').classList.remove('hidden');
    btn.querySelector('.login-btn-loader').classList.add('hidden');

    if (error) {
      emailInput.classList.add('error');
      passwordInput.classList.add('error');
      showError(passwordInput, 'senha incorreta');
      alert("ERRO SUPABASE: " + error.message);
      return;
    }
  } catch (err) {
    btn.classList.remove('loading');
    btn.querySelector('.login-btn-text').classList.remove('hidden');
    btn.querySelector('.login-btn-loader').classList.add('hidden');
    showError(passwordInput, 'Erro crítico no script');
    alert("ERRO CATCH: " + err.message);
  }
}

function showError(input, message) {
  removeError(input);
  const errorEl = document.createElement('div');
  errorEl.className = 'form-error';
  errorEl.textContent = message;
  input.closest('.form-group').appendChild(errorEl);
}

function removeError(input) {
  const group = input.closest('.form-group');
  const existing = group.querySelector('.form-error');
  if (existing) existing.remove();
}

// =============================================
// FETCH LEADS & REALTIME
// =============================================
async function fetchLeads() {
  const { data: leadsData, error: leadsErr } = await db
    .from('samukas_leads')
    .select('*')
    .eq('lead_ativo', true);

  if (leadsErr) {
    console.error('Error fetching leads:', leadsErr);
    return;
  }

  // Buscar mensagens para identificar os leads com mensagens e obter a prévia da última mensagem e data criado_em
  const { data: messagesData, error: msgsErr } = await db
    .from('samukas_mensagens')
    .select('lead_id, mensagem_conteudo, criado_em')
    .not('lead_id', 'is', null)
    .order('criado_em', { ascending: false });

  if (msgsErr) {
    console.error('Error fetching messages summary:', msgsErr);
  }

  const latestMsgByLead = new Map();
  if (messagesData) {
    for (const msg of messagesData) {
      if (msg.lead_id && !latestMsgByLead.has(msg.lead_id)) {
        latestMsgByLead.set(msg.lead_id, msg);
      }
    }
  }

  // Incluir leads ativos
  let leadsList = (leadsData || []).map(lead => {
    const latest = latestMsgByLead.get(lead.lead_id);
    return {
      ...lead,
      lead_mensagem: latest ? latest.mensagem_conteudo : (lead.lead_mensagem || ''),
      criado_em: latest ? latest.criado_em : lead.lead_ultima_compra
    };
  });

  // Buscar se existem mensagens sem vínculo com nenhum lead (lead_id is null)
  const { data: noLeadMsgs, error: noLeadErr } = await db
    .from('samukas_mensagens')
    .select('*')
    .is('lead_id', null)
    .order('criado_em', { ascending: false })
    .limit(1);

  if (!noLeadErr && noLeadMsgs && noLeadMsgs.length > 0) {
    const latestMsg = noLeadMsgs[0];
    leadsList.unshift({
      lead_id: 'no_lead',
      lead_nome: 'Novo Lead',
      lead_telefone: 'Sem Vínculo',
      lead_mensagem: latestMsg.mensagem_conteudo || '',
      criado_em: latestMsg.criado_em,
      is_no_lead: true
    });
  }

  // Ordenar conversas das mais recentes para as mais antigas usando a coluna criado_em da tabela samukas_mensagens
  leadsList.sort((a, b) => {
    if (a.is_no_lead) return -1;
    if (b.is_no_lead) return 1;
    const timeA = a.criado_em ? new Date(a.criado_em).getTime() : 0;
    const timeB = b.criado_em ? new Date(b.criado_em).getTime() : 0;
    return timeB - timeA;
  });

  state.leads = leadsList;
  renderChatList(searchInput.value);
}

async function openChat(leadId) {
  state.activeChat = leadId;
  const lead = state.leads.find(l => l.lead_id === leadId);
  if (!lead) return;

  // Alternar para a visão de conversa
  switchView('chat');

  // Update sidebar
  renderChatList(searchInput.value);

  // Show chat UI
  emptyState.classList.add('hidden');
  chatHeader.classList.remove('hidden');
  messagesContainer.classList.remove('hidden');
  
  const watermark = document.getElementById('chat-watermark');
  if (watermark) watermark.classList.remove('hidden');

  // Mobile: hide conversation list, show thread only
  if (window.innerWidth <= 768) {
    conversationListPane.classList.add('hide-mobile');
  }

  const name = lead.lead_nome || 'Lead Sem Nome';
  // Update header
  if (lead.is_no_lead) {
    contactAvatar.style.background = '#e63946';
    contactAvatar.innerHTML = 'NL';
    contactName.textContent = 'Novo Lead';
    contactStatus.textContent = 'Sem vínculo';
  } else {
    contactAvatar.style.background = getAvatarColor(lead.lead_id);
    contactAvatar.innerHTML = name.substring(0, 2).toUpperCase();
    contactName.textContent = name;
    contactStatus.textContent = lead.lead_telefone ? lead.lead_telefone : 'Online';
  }
  contactStatus.className = 'contact-status';

  // Fetch messages from DB
  await fetchMessages(leadId);

  // Close info panel
  closeInfoPanel();
}

// =============================================
// VIEW SWITCHER
// =============================================
function switchView(viewName) {
  state.currentView = viewName;
  const tabDashboard = $('#tab-dashboard');
  const tabChat = $('#tab-chat');
  const tabConfig = $('#tab-config');
  const viewDashboard = $('#view-dashboard');
  const viewChat = $('#view-chat');
  const viewConfig = $('#view-config');

  [tabDashboard, tabChat, tabConfig].forEach(t => t && t.classList.remove('active'));
  [viewDashboard, viewChat, viewConfig].forEach(v => v && v.classList.add('hidden'));

  if (viewName === 'dashboard') {
    if (tabDashboard) tabDashboard.classList.add('active');
    if (viewDashboard) viewDashboard.classList.remove('hidden');
  } else if (viewName === 'config') {
    if (tabConfig) tabConfig.classList.add('active');
    if (viewConfig) viewConfig.classList.remove('hidden');
    fetchTemplateConfig();
  } else {
    if (tabChat) tabChat.classList.add('active');
    if (viewChat) viewChat.classList.remove('hidden');
  }
}

// =============================================
// TEMPLATE CONFIG (Portal -> n8n Disparo de Mensagens)
// =============================================
async function fetchTemplateConfig() {
  const statusEl = $('#template-config-status');
  try {
    const { data, error } = await db
      .from('samukas_configuracoes')
      .select('template_mensagem')
      .eq('id', 1)
      .single();

    if (error) throw error;
    renderTemplateOptions(data ? data.template_mensagem : 'cupom_botao');
  } catch (err) {
    console.error('Erro ao buscar configuração de template:', err);
    if (statusEl) {
      statusEl.textContent = 'Não foi possível carregar a configuração atual.';
      statusEl.className = 'template-config-status error';
    }
  }
}

function renderTemplateOptions(activeTemplate) {
  $$('.template-option').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.template === activeTemplate);
  });
}

async function setActiveTemplate(templateName) {
  const statusEl = $('#template-config-status');
  const buttons = $$('.template-option');
  buttons.forEach(b => b.disabled = true);
  if (statusEl) {
    statusEl.textContent = 'Salvando...';
    statusEl.className = 'template-config-status';
  }

  try {
    const { error } = await db
      .from('samukas_configuracoes')
      .update({ template_mensagem: templateName, atualizado_em: new Date().toISOString() })
      .eq('id', 1);

    if (error) throw error;

    renderTemplateOptions(templateName);
    if (statusEl) {
      const label = templateName === 'cupom_botao' ? 'Cupom + Botão (Imagem)' : 'Cupom 15 (Texto Simples)';
      statusEl.textContent = `✅ Template ativo atualizado para: ${label}. A próxima automação de disparo já vai usar esse modelo.`;
      statusEl.className = 'template-config-status success';
    }
  } catch (err) {
    console.error('Erro ao salvar template ativo:', err);
    if (statusEl) {
      statusEl.textContent = 'Erro ao salvar a configuração. Tente novamente.';
      statusEl.className = 'template-config-status error';
    }
  } finally {
    buttons.forEach(b => b.disabled = false);
  }
}

// =============================================
// PENDING LEADS INDICATOR (Dashboard)
// =============================================
async function fetchPendingLeadsCount() {
  const indicator = $('#pending-leads-indicator');
  const textEl = $('#pending-leads-text');
  if (!indicator || !textEl) return;

  try {
    // Same eligibility filter used by the "Puxar LEADS" node in the
    // Disparo de Mensagens automation: active leads not yet messaged.
    const { count, error } = await db
      .from('samukas_leads')
      .select('lead_id', { count: 'exact', head: true })
      .eq('lead_ativo', true)
      .or('lead_mensagem.is.null,lead_mensagem.eq.');

    if (error) throw error;

    indicator.classList.remove('has-pending', 'no-pending', 'error');
    if (count > 0) {
      indicator.classList.add('has-pending');
      textEl.textContent = `${count} ${count === 1 ? 'lead aguardando' : 'leads aguardando'} envio`;
    } else {
      indicator.classList.add('no-pending');
      textEl.textContent = 'Nenhum lead pendente de envio';
    }
  } catch (err) {
    console.error('Erro ao buscar leads pendentes:', err);
    indicator.classList.remove('has-pending', 'no-pending');
    indicator.classList.add('error');
    textEl.textContent = 'Não foi possível verificar leads pendentes';
  }
}

// =============================================
// LEAD IMPORT (Configurações — planilha -> samukas_leads)
// =============================================
const LEAD_IMPORT_FIELDS = [
  { key: 'nome', label: 'Nome', required: true, synonyms: ['nome', 'cliente', 'nomecliente'] },
  { key: 'telefone', label: 'Telefone', required: true, synonyms: ['telefone', 'celular', 'whatsapp', 'fone', 'telefonecelular'] },
  { key: 'quantidade_pedidos', label: 'Qtd. Pedidos', required: false, synonyms: ['qtdpedidos', 'quantidadepedidos', 'qtdedidos', 'pedidos', 'qtddepedidos'] },
  { key: 'valor_total', label: 'Valor Total', required: false, synonyms: ['valortotal', 'valortotalgasto'] },
  { key: 'ticket_medio', label: 'Ticket Médio', required: false, synonyms: ['ticketmedio'] },
  { key: 'ultima_compra', label: 'Última Compra', required: false, synonyms: ['ultimacompra', 'dataultimacompra'] }
];

function normalizeImportHeader(str) {
  return String(str || '')
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

function parsePtBrNumber(val) {
  if (val === null || val === undefined || val === '') return null;
  if (typeof val === 'number') return isNaN(val) ? null : val;
  const cleaned = String(val).trim().replace(/\./g, '').replace(',', '.');
  const n = parseFloat(cleaned);
  return isNaN(n) ? null : n;
}

function parsePtBrDate(val) {
  if (!val) return null;
  if (val instanceof Date && !isNaN(val.getTime())) {
    const y = val.getFullYear();
    const m = String(val.getMonth() + 1).padStart(2, '0');
    const d = String(val.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  const match = String(val).trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (match) {
    const [, dd, mm, yyyy] = match;
    return `${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
  }
  return null;
}

function extractFirstPhone(val) {
  if (!val) return '';
  const first = String(val).split(';')[0];
  return first.replace(/\D/g, '');
}

function resetImportFlow() {
  const fileInput = $('#import-file-input');
  if (fileInput) fileInput.value = '';
  const statusEl = $('#import-file-status');
  if (statusEl) { statusEl.textContent = ''; statusEl.className = 'template-config-status'; }
  $('#import-step-file').classList.remove('hidden');
  $('#import-step-mapping').classList.add('hidden');
  $('#import-step-result').classList.add('hidden');
  state.importHeaders = [];
  state.importRows = [];
  state.importMapping = {};
}

function renderImportMapping() {
  const grid = $('#import-mapping-grid');
  if (!grid) return;

  grid.innerHTML = LEAD_IMPORT_FIELDS.map(f => {
    const options = state.importHeaders.map((h, i) =>
      `<option value="${i}" ${state.importMapping[f.key] === i ? 'selected' : ''}>${h || ('(coluna ' + (i + 1) + ')')}</option>`
    ).join('');
    const ignoreOption = !f.required
      ? `<option value="-1" ${state.importMapping[f.key] === -1 ? 'selected' : ''}>(Ignorar)</option>`
      : `<option value="-1" ${state.importMapping[f.key] === -1 ? 'selected' : ''} disabled>Selecione uma coluna</option>`;

    return `
      <div class="import-mapping-field">
        <label>${f.label}${f.required ? '<span class="required-mark">*</span>' : ''}</label>
        <select data-field="${f.key}">
          ${ignoreOption}
          ${options}
        </select>
      </div>
    `;
  }).join('');

  grid.querySelectorAll('select').forEach(sel => {
    sel.addEventListener('change', () => {
      state.importMapping[sel.dataset.field] = parseInt(sel.value, 10);
      renderImportPreview();
    });
  });
}

function renderImportPreview() {
  const theadRow = $('#import-preview-head');
  const tbody = $('#import-preview-body');
  const info = $('#import-preview-info');
  if (!theadRow || !tbody) return;

  theadRow.innerHTML = LEAD_IMPORT_FIELDS.map(f => `<th>${f.label}</th>`).join('');

  const sampleRows = state.importRows.slice(0, 8);
  tbody.innerHTML = sampleRows.map(row => {
    return '<tr>' + LEAD_IMPORT_FIELDS.map(f => {
      const idx = state.importMapping[f.key];
      if (idx == null || idx < 0) return '<td style="color: var(--text-tertiary);">—</td>';
      const raw = row[idx];
      let display;
      if (f.key === 'telefone') display = extractFirstPhone(raw) || '(sem telefone)';
      else if (f.key === 'valor_total' || f.key === 'ticket_medio') display = parsePtBrNumber(raw);
      else if (f.key === 'ultima_compra') display = parsePtBrDate(raw);
      else display = raw;
      return `<td>${(display === null || display === undefined || display === '') ? '<span style="color: var(--text-tertiary);">—</span>' : display}</td>`;
    }).join('') + '</tr>';
  }).join('');

  if (info) {
    info.textContent = `${state.importRows.length} linha(s) lida(s) na planilha — mostrando as primeiras ${sampleRows.length}.`;
  }
}

async function handleImportFile(file) {
  const statusEl = $('#import-file-status');
  if (statusEl) {
    statusEl.textContent = 'Lendo planilha...';
    statusEl.className = 'template-config-status';
  }

  try {
    if (typeof XLSX === 'undefined') throw new Error('Biblioteca de planilha não carregou. Recarregue a página.');

    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: 'array', cellDates: true });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true, defval: '' });

    if (!rows || rows.length < 2) throw new Error('Planilha vazia ou sem linhas de dados.');

    const headers = rows[0].map(h => String(h || '').trim());
    const dataRows = rows.slice(1).filter(r => r.some(c => c !== '' && c !== null && c !== undefined));

    if (dataRows.length === 0) throw new Error('Nenhuma linha de dados encontrada na planilha.');

    state.importHeaders = headers;
    state.importRows = dataRows;
    state.importMapping = {};

    const normHeaders = headers.map(normalizeImportHeader);
    LEAD_IMPORT_FIELDS.forEach(f => {
      let idx = normHeaders.findIndex(h => f.synonyms.includes(h));
      if (idx === -1) idx = normHeaders.findIndex(h => h && f.synonyms.some(s => h.includes(s)));
      state.importMapping[f.key] = idx;
    });

    renderImportMapping();
    renderImportPreview();

    $('#import-step-file').classList.add('hidden');
    $('#import-step-result').classList.add('hidden');
    $('#import-step-mapping').classList.remove('hidden');
  } catch (err) {
    console.error('Erro ao ler planilha:', err);
    if (statusEl) {
      statusEl.textContent = 'Erro ao ler a planilha: ' + err.message;
      statusEl.className = 'template-config-status error';
    }
  }
}

async function confirmLeadImport() {
  const nomeIdx = state.importMapping.nome;
  const telIdx = state.importMapping.telefone;

  if (nomeIdx == null || nomeIdx < 0 || telIdx == null || telIdx < 0) {
    alert('Selecione as colunas de Nome e Telefone antes de confirmar — esses dois campos são obrigatórios.');
    return;
  }

  const btn = $('#btn-import-confirm');
  const btnSpan = btn ? btn.querySelector('span') : null;
  if (btn) btn.disabled = true;
  if (btnSpan) btnSpan.textContent = 'Importando...';

  try {
    const qtdIdx = state.importMapping.quantidade_pedidos;
    const valorIdx = state.importMapping.valor_total;
    const ticketIdx = state.importMapping.ticket_medio;
    const dataIdx = state.importMapping.ultima_compra;

    const candidates = [];
    const seenPhones = new Set();
    let semTelefone = 0;

    for (const row of state.importRows) {
      const phone = extractFirstPhone(row[telIdx]);
      if (!phone) { semTelefone++; continue; }
      if (seenPhones.has(phone)) continue;
      seenPhones.add(phone);

      const nome = String(row[nomeIdx] || '').trim();
      candidates.push({
        lead_nome: nome || null,
        lead_telefone: phone,
        lead_quantidade_pedidos: qtdIdx >= 0 ? (() => { const n = parsePtBrNumber(row[qtdIdx]); return n == null ? null : Math.round(n); })() : null,
        lead_valor_total: valorIdx >= 0 ? parsePtBrNumber(row[valorIdx]) : null,
        lead_ticket_medio: ticketIdx >= 0 ? parsePtBrNumber(row[ticketIdx]) : null,
        lead_ultima_compra: dataIdx >= 0 ? parsePtBrDate(row[dataIdx]) : null,
        lead_ativo: true
      });
    }

    if (candidates.length === 0) {
      alert('Nenhuma linha com telefone válido foi encontrada para importar.');
      return;
    }

    // Check which phones already exist, in chunks (defensive against very large sheets)
    const phones = candidates.map(c => c.lead_telefone);
    const existingPhones = new Set();
    const CHUNK = 300;
    for (let i = 0; i < phones.length; i += CHUNK) {
      const chunk = phones.slice(i, i + CHUNK);
      const { data, error } = await db.from('samukas_leads').select('lead_telefone').in('lead_telefone', chunk);
      if (error) throw error;
      (data || []).forEach(d => existingPhones.add(d.lead_telefone));
    }

    const toInsert = candidates.filter(c => !existingPhones.has(c.lead_telefone));
    const ignoradosExistentes = candidates.length - toInsert.length;

    let inserted = 0;
    if (toInsert.length > 0) {
      const { data, error } = await db.from('samukas_leads').insert(toInsert).select('lead_id');
      if (error) throw error;
      inserted = data ? data.length : 0;
    }

    $('#import-step-mapping').classList.add('hidden');
    $('#import-step-result').classList.remove('hidden');
    const resultEl = $('#import-result-summary');
    if (resultEl) {
      resultEl.className = 'template-config-status success';
      resultEl.textContent = `✅ ${inserted} novo(s) lead(s) importado(s) · ${ignoradosExistentes} ignorado(s) (telefone já cadastrado) · ${semTelefone} linha(s) sem telefone válido.`;
    }

    fetchPendingLeadsCount();
  } catch (err) {
    console.error('Erro ao importar leads:', err);
    $('#import-step-mapping').classList.add('hidden');
    $('#import-step-result').classList.remove('hidden');
    const resultEl = $('#import-result-summary');
    if (resultEl) {
      resultEl.className = 'template-config-status error';
      resultEl.textContent = 'Erro ao importar leads: ' + err.message;
    }
  } finally {
    if (btn) btn.disabled = false;
    if (btnSpan) btnSpan.textContent = 'Confirmar Importação';
  }
}

// =============================================
// RESEND TO LEAD BASE (Configurações)
// =============================================
// Mirrors the Disparo de Mensagens automation: 40 leads per run,
// 5 runs a day (17:30, 18:00, 18:30, 19:00, 19:30).
const DISPATCH_PER_RUN = 40;
const DISPATCH_RUNS_PER_DAY = 5;

function setResendStatus(text, kind) {
  const el = $('#resend-status');
  if (!el) return;
  el.textContent = text || '';
  el.className = 'template-config-status' + (kind ? ' ' + kind : '');
}

function showResendStep(step) {
  $('#resend-step-idle').classList.toggle('hidden', step !== 'idle');
  $('#resend-step-confirm').classList.toggle('hidden', step !== 'confirm');
}

async function startResend() {
  const btn = $('#btn-resend-start');
  if (btn) btn.disabled = true;
  setResendStatus('Contando leads...', '');

  try {
    const { count, error } = await db
      .from('samukas_leads')
      .select('lead_id', { count: 'exact', head: true })
      .eq('lead_ativo', true)
      .not('lead_mensagem', 'is', null)
      .neq('lead_mensagem', '');

    if (error) throw error;

    if (!count) {
      setResendStatus('Nenhum lead enviado para reenfileirar — todos os leads ativos já estão na fila.', '');
      return;
    }

    const perDay = DISPATCH_PER_RUN * DISPATCH_RUNS_PER_DAY;
    const days = Math.ceil(count / perDay);
    $('#resend-confirm-text').innerHTML =
      `Isso vai recolocar <strong>${count.toLocaleString('pt-BR')} leads</strong> na fila de disparo. ` +
      `A automação envia ${DISPATCH_PER_RUN} por execução, ${DISPATCH_RUNS_PER_DAY} vezes ao dia ` +
      `(~${perDay} por dia), então levaria cerca de <strong>${days} ${days === 1 ? 'dia' : 'dias'}</strong> ` +
      `para chegar em todos. Mensagens já enviadas não são desfeitas.`;

    state.resendCount = count;
    setResendStatus('', '');
    showResendStep('confirm');
  } catch (err) {
    console.error('Erro ao contar leads para reenvio:', err);
    setResendStatus('Não foi possível contar os leads. Tente novamente.', 'error');
  } finally {
    if (btn) btn.disabled = false;
  }
}

function cancelResend() {
  setResendStatus('', '');
  showResendStep('idle');
}

async function confirmResend() {
  const btn = $('#btn-resend-confirm');
  const btnSpan = btn ? btn.querySelector('span') : null;
  if (btn) btn.disabled = true;
  if (btnSpan) btnSpan.textContent = 'Reenfileirando...';

  try {
    const { count, error } = await db
      .from('samukas_leads')
      .update({ lead_mensagem: null }, { count: 'exact' })
      .eq('lead_ativo', true)
      .not('lead_mensagem', 'is', null);

    if (error) throw error;

    showResendStep('idle');
    setResendStatus(`✅ ${(count || 0).toLocaleString('pt-BR')} leads recolocados na fila. A próxima execução da automação já começa a enviar.`, 'success');
    fetchPendingLeadsCount();
  } catch (err) {
    console.error('Erro ao reenfileirar leads:', err);
    showResendStep('idle');
    setResendStatus('Erro ao reenfileirar os leads: ' + err.message, 'error');
  } finally {
    if (btn) btn.disabled = false;
    if (btnSpan) btnSpan.textContent = 'Confirmar reenvio';
  }
}

// =============================================
// KPI & METRICS DASHBOARD
// =============================================
function renderKPISkeletons() {
  const container = $('#kpi-cards-container');
  if (!container) return;

  container.innerHTML = Array(4).fill(0).map(() => `
    <div class="kpi-skeleton-card">
      <div class="kpi-skeleton-header">
        <div class="kpi-skeleton-block kpi-skeleton-label"></div>
        <div class="kpi-skeleton-block kpi-skeleton-icon"></div>
      </div>
      <div class="kpi-skeleton-block kpi-skeleton-value"></div>
      <div class="kpi-skeleton-block kpi-skeleton-subtext"></div>
    </div>
  `).join('');
}

function filterLeadsByPeriod(leads, period) {
  if (!period || period === 'todos') return leads;

  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
  const todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

  return leads.filter(lead => {
    const dateStr = lead.data_disparo_mensagem || lead.criado_em || lead.lead_ultima_compra;
    if (!dateStr) return false;
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return false;

    if (period === 'hoje') {
      return d >= todayStart && d <= todayEnd;
    } else if (period === 'ontem') {
      const yesterdayStart = new Date(todayStart);
      yesterdayStart.setDate(yesterdayStart.getDate() - 1);
      const yesterdayEnd = new Date(todayEnd);
      yesterdayEnd.setDate(yesterdayEnd.getDate() - 1);
      return d >= yesterdayStart && d <= yesterdayEnd;
    } else if (period === '7dias') {
      const sevenDaysAgo = new Date(todayStart);
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      return d >= sevenDaysAgo && d <= todayEnd;
    } else if (period === 'mes') {
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
      return d >= monthStart && d <= todayEnd;
    }
    return true;
  });
}

function filterVendasByPeriod(vendas, period) {
  if (!period || period === 'todos') return vendas;

  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
  const todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

  return vendas.filter(v => {
    const dateStr = v.criado_em;
    if (!dateStr) return false;
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return false;

    if (period === 'hoje') {
      return d >= todayStart && d <= todayEnd;
    } else if (period === 'ontem') {
      const yesterdayStart = new Date(todayStart);
      yesterdayStart.setDate(yesterdayStart.getDate() - 1);
      const yesterdayEnd = new Date(todayEnd);
      yesterdayEnd.setDate(yesterdayEnd.getDate() - 1);
      return d >= yesterdayStart && d <= yesterdayEnd;
    } else if (period === '7dias') {
      const sevenDaysAgo = new Date(todayStart);
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      return d >= sevenDaysAgo && d <= todayEnd;
    } else if (period === 'mes') {
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
      return d >= monthStart && d <= todayEnd;
    }
    return true;
  });
}

// Global function to open chat from orders table
window.openChatFromTable = function(leadId) {
  if (!leadId) {
    alert('Venda geral do cupom (sem lead vinculado).');
    return;
  }
  const lead = state.leads.find(l => l.lead_id === leadId);
  if (lead) {
    openChat(leadId);
  } else {
    // If lead is not in chat list, open chat view anyway
    switchView('chat');
  }
};

async function fetchKPIs() {
  const container = $('#kpi-cards-container');
  const refreshBtn = $('#btn-refresh-kpis');
  const summaryText = $('#summary-text');
  const ordersCountBadge = $('#orders-count-badge');
  if (!container) return;

  if (refreshBtn) refreshBtn.classList.add('loading');

  try {
    // 1. Buscar Leads
    const { data: leadsData, error: leadsErr } = await db
      .from('samukas_leads')
      .select('lead_id, lead_nome, lead_telefone, lead_ativo, lead_comprou, compra_valor, lead_valor_total, lead_quantidade_pedidos, lead_ultima_compra, lead_mensagem, data_disparo_mensagem, criado_em')
      .order('data_disparo_mensagem', { ascending: false });

    // 2. Buscar Vendas com Itens
    const { data: vendasData, error: vendasErr } = await db
      .from('samukas_vendas')
      .select('id_sale, cliente_nome, cliente_telefone, cliente_id, criado_em, total_vendido, cupom_desconto, lead_id, itens_pedido')
      .order('criado_em', { ascending: false });

    if (leadsErr) {
      console.error('Erro ao buscar dados de samukas_leads para KPIs:', leadsErr);
      container.innerHTML = `
        <div style="grid-column: 1 / -1; padding: 16px; background: rgba(230,57,70,0.1); border: 1px solid rgba(230,57,70,0.3); border-radius: 12px; color: #ff6b6b; font-size: 0.85rem; text-align: center;">
          Não foi possível carregar as métricas do Supabase.
        </div>
      `;
      return;
    }

    const rawLeads = leadsData || [];
    const leads = filterLeadsByPeriod(rawLeads, state.periodFilter);

    const rawVendas = vendasData || [];
    const vendas = filterVendasByPeriod(rawVendas, state.periodFilter);

    if (ordersCountBadge) {
      ordersCountBadge.textContent = `${vendas.length} ${vendas.length === 1 ? 'Pedido' : 'Pedidos'}`;
    }

    // 1. Disparos Realizados: Contagem de leads com data_disparo_mensagem ou mensagem de disparo
    const disparosLeads = leads.filter(l => {
      if (l.data_disparo_mensagem) return true;
      if (l.lead_mensagem) {
        const msgStr = String(l.lead_mensagem).trim().toLowerCase();
        return msgStr.includes('mensagem 1');
      }
      return false;
    });

    const totalDisparos = disparosLeads.length > 0 ? disparosLeads.length : leads.length;

    // 2. Vendas Convertidas: Total de vendas ou compradores
    const compradores = leads.filter(l => Boolean(l.lead_comprou));
    const vendasConvertidas = vendas.length > 0 ? vendas.length : compradores.length;

    // 3. Faturamento Gerado: Soma do total vendido em samukas_vendas (ou leads)
    let faturamentoGeradoVal = 0;
    if (vendas.length > 0) {
      faturamentoGeradoVal = vendas.reduce((sum, v) => sum + (Number(v.total_vendido) || 0), 0);
    } else {
      faturamentoGeradoVal = compradores.reduce((sum, l) => {
        const val = l.compra_valor != null ? Number(l.compra_valor) : Number(l.lead_valor_total || 0);
        return sum + (isNaN(val) ? 0 : val);
      }, 0);
    }

    const faturamentoStr = faturamentoGeradoVal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

    // 4. Taxa de Conversão (%): Porcentagem de conversões sobre os disparos
    const taxaConversaoVal = totalDisparos > 0 ? (vendasConvertidas / totalDisparos) * 100 : 0;
    const taxaConversaoStr = taxaConversaoVal.toFixed(1).replace('.', ',') + '%';

    // Rótulo temporal dinâmico para o banner
    let periodPrefix = "No geral";
    if (state.periodFilter === 'hoje') periodPrefix = "Hoje";
    else if (state.periodFilter === 'ontem') periodPrefix = "Ontem";
    else if (state.periodFilter === '7dias') periodPrefix = "Nos últimos 7 dias";
    else if (state.periodFilter === 'mes') periodPrefix = "Neste mês";

    if (summaryText) {
      summaryText.innerHTML = `${periodPrefix} foram feitos <strong style="color: #ffffff;">${totalDisparos} disparos</strong>, gerando <strong style="color: #2ec4b6;">${vendasConvertidas} ${vendasConvertidas === 1 ? 'venda' : 'vendas'}</strong> e <strong style="color: #ffcc00;">${faturamentoStr}</strong> de faturamento (Conversão: <strong style="color: #ff6b6b;">${taxaConversaoStr}</strong>).`;
    }

    renderKPICards({
      disparos: `${totalDisparos} disparos`,
      vendas: `${vendasConvertidas} ${vendasConvertidas === 1 ? 'venda' : 'vendas'}`,
      faturamento: faturamentoStr,
      taxaConversao: taxaConversaoStr,
      totalDisparos,
      vendasConvertidas
    });

    // Salvar vendas filtradas no estado e renderizar tabela paginada
    state.currentFilteredVendas = vendas;
    renderOrdersTable();


    // =============================================
    // PRODUTOS MAIS VENDIDOS & INSIGHTS DE PRODUTOS
    // =============================================
    const productStatsMap = new Map();
    const choicesStatsMap = new Map();

    for (const v of vendas) {
      const itens = Array.isArray(v.itens_pedido) ? v.itens_pedido : [];
      for (const item of itens) {
        const nome = item.nome || 'Produto';
        const qtd = Number(item.quantidade || 1);
        const precoUnit = Number(item.preco_unitario || 0);
        const totalRev = qtd * precoUnit;

        const current = productStatsMap.get(nome) || { nome, qtd: 0, faturamento: 0 };
        current.qtd += qtd;
        current.faturamento += totalRev;
        productStatsMap.set(nome, current);

        // Agrega escolhas/adicionais
        const opcoes = Array.isArray(item.opcoes) ? item.opcoes : [];
        for (const op of opcoes) {
          const opNome = (op.nome || '').trim();
          if (opNome) {
            choicesStatsMap.set(opNome, (choicesStatsMap.get(opNome) || 0) + 1);
          }
        }
      }
    }

    // Salvar rankings ordenados no estado e renderizar com paginação
    state.currentTopProducts = Array.from(productStatsMap.values()).sort((a, b) => b.qtd - a.qtd || b.faturamento - a.faturamento);
    state.productsPage = 1;
    renderTopProducts();

    state.currentTopChoices = Array.from(choicesStatsMap.entries())
      .map(([nome, count]) => ({ nome, count }))
      .sort((a, b) => b.count - a.count);
    state.choicesPage = 1;
    renderTopChoices();

  } catch (err) {
    console.error('Erro ao processar KPIs:', err);
  } finally {
    if (refreshBtn) {
      setTimeout(() => refreshBtn.classList.remove('loading'), 450);
    }
  }
}

function renderKPICards(kpi) {
  const container = $('#kpi-cards-container');
  if (!container) return;

  container.innerHTML = `
    <!-- Card 1: Disparos Realizados -->
    <div class="kpi-card kpi-card-disparos" style="--card-accent: #3b82f6; --card-glow: rgba(59, 130, 246, 0.2); --icon-bg: rgba(59, 130, 246, 0.15); --icon-color: #60a5fa; --icon-border: rgba(59, 130, 246, 0.3);">
      <div class="kpi-card-top">
        <span class="kpi-card-label">Disparos Realizados</span>
        <div class="kpi-card-icon-box">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
        </div>
      </div>
      <div class="kpi-card-value">${kpi.disparos}</div>
      <div class="kpi-card-subtext">Total de mensagens disparadas</div>
    </div>

    <!-- Card 2: Vendas Convertidas -->
    <div class="kpi-card kpi-card-buyers">
      <div class="kpi-card-top">
        <span class="kpi-card-label">Vendas Convertidas</span>
        <div class="kpi-card-icon-box">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
        </div>
      </div>
      <div class="kpi-card-value">${kpi.vendas}</div>
      <div class="kpi-card-subtext">Pedidos gerados após o disparo</div>
    </div>

    <!-- Card 3: Faturamento Gerado -->
    <div class="kpi-card kpi-card-revenue">
      <div class="kpi-card-top">
        <span class="kpi-card-label">Faturamento Gerado</span>
        <div class="kpi-card-icon-box">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
        </div>
      </div>
      <div class="kpi-card-value">${kpi.faturamento}</div>
      <div class="kpi-card-subtext">Valor total das vendas atribuídas</div>
    </div>

    <!-- Card 4: Taxa de Conversão (%) -->
    <div class="kpi-card kpi-card-conversion">
      <div class="kpi-card-top">
        <span class="kpi-card-label">Taxa de Conversão</span>
        <div class="kpi-card-icon-box">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
        </div>
      </div>
      <div class="kpi-card-value">${kpi.taxaConversao}</div>
      <div class="kpi-card-subtext">${kpi.vendasConvertidas} conversões sobre ${kpi.totalDisparos} disparos</div>
    </div>
  `;
}

// =============================================
// ORDERS TABLE & PAGINATION (10 per page)
// =============================================
function renderOrdersTable() {
  const tbody = $('#recent-buyers-tbody');
  const countBadge = $('#orders-count-badge');
  const paginationContainer = $('#orders-pagination-container');
  const paginationInfo = $('#orders-pagination-info');
  const paginationPages = $('#orders-pagination-pages');
  const btnPrev = $('#btn-orders-prev');
  const btnNext = $('#btn-orders-next');

  const vendas = state.currentFilteredVendas || [];
  const totalOrders = vendas.length;
  const perPage = state.ordersPerPage || 10;
  const totalPages = Math.ceil(totalOrders / perPage) || 1;

  if (state.ordersPage > totalPages) {
    state.ordersPage = totalPages;
  }
  if (state.ordersPage < 1) {
    state.ordersPage = 1;
  }

  if (countBadge) {
    countBadge.textContent = `${totalOrders} ${totalOrders === 1 ? 'Pedido' : 'Pedidos'}`;
  }

  if (!tbody) return;

  if (totalOrders === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-tertiary); padding: 30px;">Nenhum pedido registrado no período selecionado.</td></tr>`;
    if (paginationContainer) paginationContainer.classList.add('hidden');
    return;
  }

  if (paginationContainer) paginationContainer.classList.remove('hidden');

  const startIndex = (state.ordersPage - 1) * perPage;
  const endIndex = Math.min(startIndex + perPage, totalOrders);
  const pageVendas = vendas.slice(startIndex, endIndex);

  tbody.innerHTML = pageVendas.map(v => {
    const nomeCliente = v.cliente_nome ? v.cliente_nome.trim() : 'Cliente Anônimo';
    const telVal = v.cliente_telefone ? String(v.cliente_telefone).trim() : '';
    const hasPhone = telVal && telVal !== 'null' && telVal !== 'Não informado' && telVal.length > 0;
    
    const valorFormatado = Number(v.total_vendido || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    const cupom = v.cupom_desconto || 'SMK15';
    
    const dataObj = v.criado_em ? new Date(v.criado_em) : null;
    const dataFormatada = dataObj 
      ? `${dataObj.toLocaleDateString('pt-BR')} <span style="color: var(--text-tertiary); font-size: 0.75rem;">${dataObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>` 
      : 'Data não informada';

    // Itens do Pedido Formatados (Direto e Limpo: Apenas produtos e quantidades)
    const itens = Array.isArray(v.itens_pedido) ? v.itens_pedido : [];
    let itensHtml = '';

    if (itens.length === 0) {
      itensHtml = `<span style="color: var(--text-tertiary); font-style: italic; font-size: 0.8rem;">Itens não especificados</span>`;
    } else {
      itensHtml = `
        <div style="display: flex; flex-direction: column; gap: 4px;">
          ${itens.map(item => {
            const itemNome = item.nome || 'Produto';
            const itemQtd = Number(item.quantidade || 1);
            return `
              <div style="display: flex; align-items: center; gap: 6px; font-size: 0.86rem; color: var(--text-primary);">
                <span class="order-product-qty">${itemQtd}x</span>
                <span style="font-weight: 500;">${itemNome}</span>
              </div>
            `;
          }).join('')}
        </div>
      `;
    }

    return `
      <tr>
        <td>
          <div style="display: flex; flex-direction: column; gap: 2px;">
            <strong style="color: var(--text-primary); font-size: 0.92rem;">${nomeCliente}</strong>
            ${hasPhone ? `<span style="color: var(--text-tertiary); font-size: 0.78rem;">${telVal}</span>` : ''}
          </div>
        </td>
        <td>${itensHtml}</td>
        <td><strong style="color: #ffcc00; font-size: 0.95rem;">${valorFormatado}</strong></td>
        <td><span class="badge-coupon-smk15">🎟️ ${cupom}</span></td>
        <td>${dataFormatada}</td>
        <td style="text-align: center;">
          <button class="btn-table-action" onclick="openChatFromTable('${v.lead_id || ''}')" title="Abrir conversa no chat">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            <span>Chat</span>
          </button>
        </td>
      </tr>
    `;
  }).join('');

  // Pagination Info
  if (paginationInfo) {
    paginationInfo.textContent = `Mostrando ${startIndex + 1}–${endIndex} de ${totalOrders} pedidos`;
  }

  // Prev / Next buttons state & handlers
  if (btnPrev) {
    btnPrev.disabled = state.ordersPage <= 1;
    btnPrev.onclick = () => {
      if (state.ordersPage > 1) {
        state.ordersPage--;
        renderOrdersTable();
      }
    };
  }

  if (btnNext) {
    btnNext.disabled = state.ordersPage >= totalPages;
    btnNext.onclick = () => {
      if (state.ordersPage < totalPages) {
        state.ordersPage++;
        renderOrdersTable();
      }
    };
  }

  // Page Numbers
  if (paginationPages) {
    if (totalPages <= 1) {
      paginationPages.innerHTML = '';
    } else {
      let pagesHtml = '';
      for (let p = 1; p <= totalPages; p++) {
        pagesHtml += `
          <button class="pagination-page-btn ${p === state.ordersPage ? 'active' : ''}" onclick="goToOrdersPage(${p})">${p}</button>
        `;
      }
      paginationPages.innerHTML = pagesHtml;
    }
  }
}

window.goToOrdersPage = function(pageNumber) {
  state.ordersPage = pageNumber;
  renderOrdersTable();
};

// =============================================
// TOP PRODUTOS MAIS VENDIDOS (ranking + paginação)
// =============================================
function renderTopProducts() {
  const listEl = $('#top-products-list');
  const container = $('#products-pagination-container');
  const infoEl = $('#products-pagination-info');
  const pagesEl = $('#products-pagination-pages');
  const btnPrev = $('#btn-products-prev');
  const btnNext = $('#btn-products-next');
  if (!listEl) return;

  const products = state.currentTopProducts || [];
  const total = products.length;

  if (total === 0) {
    listEl.innerHTML = `<div style="text-align: center; color: var(--text-tertiary); padding: 20px; font-size: 0.85rem;">Nenhum produto registrado no período.</div>`;
    if (container) container.classList.add('hidden');
    return;
  }

  const perPage = state.productsPerPage || 5;
  const totalPages = Math.ceil(total / perPage) || 1;
  if (state.productsPage > totalPages) state.productsPage = totalPages;
  if (state.productsPage < 1) state.productsPage = 1;

  const maxQty = products[0].qtd || 1;
  const startIndex = (state.productsPage - 1) * perPage;
  const endIndex = Math.min(startIndex + perPage, total);
  const pageProducts = products.slice(startIndex, endIndex);
  const medals = ['🥇', '🥈', '🥉'];

  listEl.innerHTML = pageProducts.map((p, i) => {
    const idx = startIndex + i;
    let rankClass = 'rank-other';
    let rankText = `#${idx + 1}`;
    if (idx === 0) { rankClass = 'rank-1'; rankText = medals[0]; }
    else if (idx === 1) { rankClass = 'rank-2'; rankText = medals[1]; }
    else if (idx === 2) { rankClass = 'rank-3'; rankText = medals[2]; }

    const pct = Math.min(100, Math.max(12, Math.round((p.qtd / maxQty) * 100)));
    const revStr = p.faturamento > 0 ? p.faturamento.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : '';

    return `
      <div class="top-product-row">
        <div class="top-product-main">
          <div class="top-product-info">
            <span class="rank-badge ${rankClass}">${rankText}</span>
            <span class="top-product-name" title="${p.nome}">${p.nome}</span>
          </div>
          <div class="top-product-stats">
            <span class="top-product-qty">${p.qtd} ${p.qtd === 1 ? 'unidade' : 'unidades'}</span>
            ${revStr ? `<span class="top-product-revenue">${revStr}</span>` : ''}
          </div>
        </div>
        <div class="product-progress-track">
          <div class="product-progress-fill" style="width: ${pct}%;"></div>
        </div>
      </div>
    `;
  }).join('');

  if (container) container.classList.remove('hidden');
  if (infoEl) infoEl.textContent = `Mostrando ${startIndex + 1}–${endIndex} de ${total} produtos`;

  if (btnPrev) {
    btnPrev.disabled = state.productsPage <= 1;
    btnPrev.onclick = () => { if (state.productsPage > 1) { state.productsPage--; renderTopProducts(); } };
  }
  if (btnNext) {
    btnNext.disabled = state.productsPage >= totalPages;
    btnNext.onclick = () => { if (state.productsPage < totalPages) { state.productsPage++; renderTopProducts(); } };
  }
  if (pagesEl) {
    if (totalPages <= 1) {
      pagesEl.innerHTML = '';
    } else {
      let html = '';
      for (let p = 1; p <= totalPages; p++) {
        html += `<button class="pagination-page-btn ${p === state.productsPage ? 'active' : ''}" onclick="goToProductsPage(${p})">${p}</button>`;
      }
      pagesEl.innerHTML = html;
    }
  }
}

window.goToProductsPage = function(pageNumber) {
  state.productsPage = pageNumber;
  renderTopProducts();
};

// =============================================
// ADICIONAIS & ESCOLHAS MAIS POPULARES (ranking + paginação)
// =============================================
function renderTopChoices() {
  const listEl = $('#top-choices-list');
  const container = $('#choices-pagination-container');
  const infoEl = $('#choices-pagination-info');
  const pagesEl = $('#choices-pagination-pages');
  const btnPrev = $('#btn-choices-prev');
  const btnNext = $('#btn-choices-next');
  if (!listEl) return;

  const choices = state.currentTopChoices || [];
  const total = choices.length;

  if (total === 0) {
    listEl.innerHTML = `<div style="text-align: center; color: var(--text-tertiary); padding: 20px; font-size: 0.85rem;">Nenhuma opção registrada no período.</div>`;
    if (container) container.classList.add('hidden');
    return;
  }

  const perPage = state.choicesPerPage || 8;
  const totalPages = Math.ceil(total / perPage) || 1;
  if (state.choicesPage > totalPages) state.choicesPage = totalPages;
  if (state.choicesPage < 1) state.choicesPage = 1;

  const maxCount = choices[0].count || 1;
  const startIndex = (state.choicesPage - 1) * perPage;
  const endIndex = Math.min(startIndex + perPage, total);
  const pageChoices = choices.slice(startIndex, endIndex);
  const medals = ['🥇', '🥈', '🥉'];

  listEl.innerHTML = pageChoices.map((c, i) => {
    const idx = startIndex + i;
    let rankClass = 'rank-other';
    let rankText = `#${idx + 1}`;
    if (idx === 0) { rankClass = 'rank-1'; rankText = medals[0]; }
    else if (idx === 1) { rankClass = 'rank-2'; rankText = medals[1]; }
    else if (idx === 2) { rankClass = 'rank-3'; rankText = medals[2]; }

    const pct = Math.min(100, Math.max(12, Math.round((c.count / maxCount) * 100)));

    return `
      <div class="top-product-row">
        <div class="top-product-main">
          <div class="top-product-info">
            <span class="rank-badge ${rankClass}">${rankText}</span>
            <span class="top-product-name" title="${c.nome}">${c.nome}</span>
          </div>
          <div class="top-product-stats">
            <span class="top-product-qty top-choice-qty">${c.count}x escolhido</span>
          </div>
        </div>
        <div class="product-progress-track">
          <div class="product-progress-fill choice-progress-fill" style="width: ${pct}%;"></div>
        </div>
      </div>
    `;
  }).join('');

  if (container) container.classList.remove('hidden');
  if (infoEl) infoEl.textContent = `Mostrando ${startIndex + 1}–${endIndex} de ${total} opções`;

  if (btnPrev) {
    btnPrev.disabled = state.choicesPage <= 1;
    btnPrev.onclick = () => { if (state.choicesPage > 1) { state.choicesPage--; renderTopChoices(); } };
  }
  if (btnNext) {
    btnNext.disabled = state.choicesPage >= totalPages;
    btnNext.onclick = () => { if (state.choicesPage < totalPages) { state.choicesPage++; renderTopChoices(); } };
  }
  if (pagesEl) {
    if (totalPages <= 1) {
      pagesEl.innerHTML = '';
    } else {
      let html = '';
      for (let p = 1; p <= totalPages; p++) {
        html += `<button class="pagination-page-btn ${p === state.choicesPage ? 'active' : ''}" onclick="goToChoicesPage(${p})">${p}</button>`;
      }
      pagesEl.innerHTML = html;
    }
  }
}

window.goToChoicesPage = function(pageNumber) {
  state.choicesPage = pageNumber;
  renderTopChoices();
};


let realtimeChannel = null;

function initRealtime() {
  if (realtimeChannel) {
    try { db.removeChannel(realtimeChannel); } catch(e) {}
    realtimeChannel = null;
  }

  realtimeChannel = db.channel('samukas_realtime_' + Date.now())
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'samukas_mensagens' },
      (payload) => {
        const newMsg = payload.new;
        const isCurrentChat = (state.activeChat === newMsg.lead_id) || (state.activeChat === 'no_lead' && newMsg.lead_id === null);
        if (isCurrentChat) {
          state.currentMessages.push(newMsg);
          renderMessages(state.currentMessages, state.leads.find(l => l.lead_id === state.activeChat));
          setTimeout(() => {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
          }, 50);
        }
      }
    )
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'samukas_leads' },
      (payload) => {
        fetchLeads();
        fetchKPIs();
      }
    )
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'samukas_vendas' },
      (payload) => {
        fetchKPIs();
      }
    )
    .subscribe();
}

// =============================================
// EVENT LISTENERS
// =============================================
let chatInitialized = false;

function initChat() {
  if (chatInitialized) return;
  chatInitialized = true;

  // Apply saved theme
  applyTheme(state.theme);

  // Fetch data, KPIs and setup realtime
  fetchLeads();
  renderKPISkeletons();
  fetchKPIs();
  initRealtime();
  renderTemplatePreviews();
  fetchPendingLeadsCount();

  // Lead import (Configurações)
  const importFileInput = $('#import-file-input');
  if (importFileInput) {
    importFileInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) handleImportFile(file);
    });
  }
  const btnImportCancel = $('#btn-import-cancel');
  if (btnImportCancel) btnImportCancel.addEventListener('click', resetImportFlow);
  const btnImportNew = $('#btn-import-new');
  if (btnImportNew) btnImportNew.addEventListener('click', resetImportFlow);
  const btnImportConfirm = $('#btn-import-confirm');
  if (btnImportConfirm) btnImportConfirm.addEventListener('click', confirmLeadImport);

  // Resend to lead base (Configurações)
  const btnResendStart = $('#btn-resend-start');
  if (btnResendStart) btnResendStart.addEventListener('click', startResend);
  const btnResendCancel = $('#btn-resend-cancel');
  if (btnResendCancel) btnResendCancel.addEventListener('click', cancelResend);
  const btnResendConfirm = $('#btn-resend-confirm');
  if (btnResendConfirm) btnResendConfirm.addEventListener('click', confirmResend);

  // Dashboard shortcut -> Configurações import card
  const btnImportShortcut = $('#btn-import-shortcut');
  if (btnImportShortcut) {
    btnImportShortcut.addEventListener('click', () => {
      switchView('config');
      setTimeout(() => {
        const card = document.querySelector('.lead-import-card');
        if (card) card.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 50);
    });
  }

  // Navigation tabs
  const tabDashboard = $('#tab-dashboard');
  const tabChat = $('#tab-chat');
  const tabConfig = $('#tab-config');

  if (tabDashboard) {
    tabDashboard.addEventListener('click', () => switchView('dashboard'));
  }
  if (tabChat) {
    tabChat.addEventListener('click', () => switchView('chat'));
  }
  if (tabConfig) {
    tabConfig.addEventListener('click', () => switchView('config'));
  }

  // Template config options
  $$('.template-option').forEach(btn => {
    btn.addEventListener('click', () => setActiveTemplate(btn.dataset.template));
  });

  // Period filter buttons
  const periodBtns = $$('.period-btn');
  periodBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      periodBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.periodFilter = btn.dataset.period;
      state.ordersPage = 1;
      fetchKPIs();
    });
  });

  // Default view
  switchView('dashboard');

  // Refresh KPIs button
  const refreshBtn = $('#btn-refresh-kpis');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => {
      fetchKPIs();
    });
  }

  // Logout button
  const logoutBtn = $('#btn-logout');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      await db.auth.signOut();
      window.location.reload();
    });
  }

  // Search
  searchInput.addEventListener('input', (e) => {
    renderChatList(e.target.value);
  });

  // Back button (mobile)
  $('#btn-back').addEventListener('click', () => {
    conversationListPane.classList.remove('hide-mobile');
    state.activeChat = null;
    emptyState.classList.remove('hidden');
    chatHeader.classList.add('hidden');
    messagesContainer.classList.add('hidden');
    const chatFooter = $('#chat-footer');
    if (chatFooter) chatFooter.classList.add('hidden');
    renderChatList(searchInput.value);
  });

  // Chat Form Submit (Send Direct Message)
  const chatForm = $('#chat-form');
  const chatInput = $('#chat-input');
  if (chatForm) {
    chatForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const text = chatInput ? chatInput.value.trim() : '';
      if (text) {
        sendMessageToLead(text);
      }
    });
  }

  // Info panel
  $('#btn-info').addEventListener('click', () => {
    if (state.infoPanelOpen) closeInfoPanel();
    else openInfoPanel();
  });
  $('#chat-contact').addEventListener('click', () => {
    if (!state.infoPanelOpen) openInfoPanel();
  });
  $('#btn-close-info').addEventListener('click', closeInfoPanel);

  // New chat button (Removed)

  // Search messages button
  $('#btn-search-messages').addEventListener('click', () => {
    const query = prompt('Pesquisar mensagens:');
    if (!query) return;
    const msgs = messagesList.querySelectorAll('.message-text');
    msgs.forEach(el => {
      const text = el.textContent;
      if (text.toLowerCase().includes(query.toLowerCase())) {
        el.closest('.message').style.background = 'var(--accent-light)';
        el.closest('.message').scrollIntoView({ behavior: 'smooth', block: 'center' });
        setTimeout(() => {
          el.closest('.message').style.background = '';
        }, 3000);
      }
    });
  });
}

// =============================================
// BOOT
// =============================================
// =============================================
// BOOT
// =============================================
// =============================================
// BOOT
// =============================================
try {
  const subtitle = document.querySelector('.login-subtitle');
  if (subtitle) subtitle.textContent = "Executando Boot...";
  
  initLogin();
  
  if (subtitle) subtitle.textContent = "Sistema Conectado - Pronto para Login";
} catch (e) {
  const subtitle = document.querySelector('.login-subtitle');
  if (subtitle) subtitle.textContent = "ERRO FATAL: " + e.message;
  console.error(e);
}
